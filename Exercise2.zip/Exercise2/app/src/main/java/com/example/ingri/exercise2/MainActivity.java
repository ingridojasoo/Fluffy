package com.example.ingri.exercise2;

import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private static Random rand = new Random();

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void onClick(View view){getWindow().getDecorView().setBackgroundColor(getColor());}

    public void onStart(View view) {
        Intent intent = new Intent(this, TheService.class);
        startService(intent);
    }

    private int getColor()
    {
        return Color.rgb(rand.nextInt(256),rand.nextInt(256),rand.nextInt(256));
    }
}
