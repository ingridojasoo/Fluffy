package com.example.ingri.exercise2;

import android.app.Service;
import android.content.Intent;
import android.os.Handler;
import android.os.IBinder;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;


public class TheService extends Service {

    @Override
    public IBinder onBind(Intent arg0) {
        return null;
    }

    public int onStartCommand (Intent intent, int flags, int startId){
        final Handler handler = new Handler();
        final int currentId = startId;
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                DateAndTime();
            }
        },5000);
        return TheService.START_STICKY;
    }

    public void DateAndTime(){
        Calendar c = Calendar.getInstance();
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        final String formattedDate = df.format(c.getTime());
        Toast.makeText(this, formattedDate, Toast.LENGTH_SHORT).show();
    }
}


