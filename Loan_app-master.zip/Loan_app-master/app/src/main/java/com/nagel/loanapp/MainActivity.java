package com.nagel.loanapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private EditText txtCost, txtLoan, txtRate, txtPaym, txtYear, txtTerm;
    private Button btnAmortisation, btnCalculate, btnClear;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnAmortisation = findViewById(R.id.btnAmortisation);
        txtCost = findViewById(R.id.txtCost);   /*Issue 4:*/
        txtLoan = findViewById(R.id.txtLoan);
        txtRate = findViewById(R.id.txtRate);
        txtPaym = findViewById(R.id.txtPaym);
        txtYear = findViewById(R.id.txtYear);
        txtTerm = findViewById(R.id.txtTerm);
        btnCalculate = findViewById(R.id.btnCalculate);
        btnClear = findViewById(R.id.btnClear);


        btnAmortisation.setOnClickListener(new View.OnClickListener() {
            @Override
            /*Issue 22*/
            public void onClick(View v) {
                if (Loan.getInstance().getPeriods() > 0) {
                    Intent intent = new Intent(getApplicationContext(), PlanActivity.class); /*
                    Issue 5:*/
                    startActivity(intent);
                }
            }
        });
        disable(txtPaym);
    }
    /* Issue 6: */
    public void disable(EditText txtPaym){
        txtPaym.setEnabled(false);
        txtPaym.setFocusable(false);
        txtPaym.setFocusableInTouchMode(false);

    }

    /* Issue 7:*/
    public void onClear(View view) {
        txtCost.setText("");
        txtLoan.setText("");
        txtRate.setText("");
        txtPaym.setText("");
        txtYear.setText("");
        txtTerm.setText("");
        Loan.getInstance().setPrincipal(1);
        Loan.getInstance().setInterestRate(1);
        Loan.getInstance().setPeriods(1);
        txtCost.requestFocus();
    }

    public void onCalculate(View view) {
        double cost = 0;
        double loan;
        double rate;
        int year; /* Issue 8:*/
        int term;
        try {
            String text = txtCost.getText().toString().trim();
            if (text.length() > 0) {
                cost = Double.parseDouble(text);
                if (cost < 0) throw new Exception();
            }
            /* Issue 9:*/
        } catch (Exception ex) {
            txtCost.requestFocus();
            return;
        }
        try {
            loan = Double.parseDouble(txtLoan.getText().toString().trim());
            if (loan < 0) throw new Exception();
        } catch (Exception ex) {
            txtLoan.requestFocus();
            return;
        }
        try {
            rate = Double.parseDouble(txtRate.getText().toString().trim());
            if (rate <= 0 && rate > 5) throw new Exception();
        } catch (Exception ex) {
            txtRate.requestFocus();
            return;
        }
        try {
            /*Issue 10:*/
            year = Integer.parseInt(txtYear.getText().toString().trim());
            if (year <= 0 && year > 6) throw new Exception(); /* Issue 11:*/
        } catch (Exception ex) {
            txtYear.requestFocus();
            return;
        }
        try {
            term = Integer.parseInt(txtTerm.getText().toString().trim());
            if (term <= 0 || term > 120) throw new Exception();
        } catch (Exception ex) {
            txtTerm.requestFocus();
            return;
        }
        Loan.getInstance().setPrincipal(loan + cost);
        Loan.getInstance().setInterestRate(rate / 100 / term);
        Loan.getInstance().setPeriods(year * term);
        txtPaym.setText(String.format("%1.2f", Loan.getInstance().payment()));

        /* Issue 12: */
    }

}

