package com.example.ingri.kivi_paber_krid;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class menyy extends AppCompatActivity {

    private EditText kasutajanimi;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menyy);

        kasutajanimi = findViewById(R.id.kasutajanimi);
    }

    public void playgame(View view) {
        if (view.getId()==R.id.play){
            if (kasutajanimi.getText().length()==0){
                Toast.makeText(this, "Please enter name", Toast.LENGTH_SHORT).show();
                return;
            }
        }
        Intent playgame = new Intent(menyy.this, game.class);
        startActivity(playgame);
    }
}
