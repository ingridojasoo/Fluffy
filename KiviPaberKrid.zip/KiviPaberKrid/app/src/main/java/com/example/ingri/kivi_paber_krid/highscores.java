package com.example.ingri.kivi_paber_krid;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.content.SharedPreferences;
import android.widget.TextView;

public class highscores extends AppCompatActivity {

    TextView gamescore;

    int lastscore;

    int best1, best2, best3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_highscores);

        gamescore = (TextView)findViewById(R.id.gamescore);

        SharedPreferences preferences = getSharedPreferences("PREFS",0 );
        lastscore = preferences.getInt("Score is ", 0);
        best1 = preferences.getInt("Score is ", 0);
        best2 = preferences.getInt("Score is ", 0);
        best3 = preferences.getInt("Score is ", 0);

        if (lastscore > best3){
            best3 = lastscore;
            SharedPreferences.Editor editor = preferences.edit();
            editor.putInt("Best 3  ", best3);
            editor.apply();
        }
        if (lastscore > best2){
            int temp = best2;
            best2 = lastscore;
            best3 = temp;
            SharedPreferences.Editor editor = preferences.edit();
            editor.putInt("Best 3  ", best3);
            editor.putInt("Best 2  ", best2);
            editor.apply();
        }
        if (lastscore > best1){
            int temp = best1;
            best1 = lastscore;
            best2 = temp;
            SharedPreferences.Editor editor = preferences.edit();
            editor.putInt("Best 2  ", best2);
            editor.putInt("Best 1  ", best1);
            editor.apply();
        }

        gamescore.setText("Score is: "+ lastscore + "\n" +
            "Best 1: " + best1 + "\n"+
            "Best 2: "+ best2 +"\n"+
            "Best 3: " + best3 + "\n");
    }

    @Override
    public void onBackPressed() {
        Intent highscores = new Intent(getApplicationContext(), game.class);
        startActivity(highscores);
        finish();
    }
}
