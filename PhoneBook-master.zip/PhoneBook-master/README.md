# PhoneBook
TARge+v17 : 17.10.18 & 24.10.18 App that was created in lesson about SQLite database

# <a href="https://github.com/hnagel413/PhoneBook/wiki/Homework">Homework assignment</a>


Video link - 17.10 tunnis tehtud tööle, mis jäi pooleli: https://1drv.ms/v/s!AlHGKy2oR11FhPsXtxC_CCHBRS-gDA

Info about SQLite database: [Database SQLite.pdf](https://github.com/hnagel413/PhoneBook/files/2486290/Database.SQLite.pdf)

Info about app: [PhoneBook.pdf](https://github.com/hnagel413/PhoneBook/files/2486284/PhoneBook.pdf)

Text file with zip codes that will be used in the app: [zipcodes.txt](https://github.com/hnagel413/PhoneBook/files/2486325/zipcodes.txt)

MainActivity layout:

![main](https://user-images.githubusercontent.com/31770163/47069740-5e5c4500-d1f8-11e8-8917-1456a374f7a4.png)

PeopleActivity layout:

![people](https://user-images.githubusercontent.com/31770163/47069800-821f8b00-d1f8-11e8-8598-2fad7c8e1bce.png)

PersonActivity layout:

![person](https://user-images.githubusercontent.com/31770163/47069820-906da700-d1f8-11e8-9434-b33ec06a8366.png)

SearchActivity layout:

![search](https://user-images.githubusercontent.com/31770163/47069834-96638800-d1f8-11e8-9259-693218b3629d.png)


