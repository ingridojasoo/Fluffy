package com.example.ingri.exercise1;

import android.app.Service;
import android.os.IBinder;
import android.content.Intent;
import android.os.Binder;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class LocalService extends Service {

    private final IBinder binder = new LocalBinder();

    @Override
    public IBinder onBind(Intent intent) {
        return binder;
    }

    public class LocalBinder extends Binder {
        LocalService getService() {
            return LocalService.this;
        }
    }

    public static String formattedDate(){
        Calendar c = Calendar.getInstance();
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        String formattedDate = df.format(c.getTime());
        return  formattedDate;
    }

    public static String formattedTime(){
        Calendar c = Calendar.getInstance();
        SimpleDateFormat df = new SimpleDateFormat("HH:mm:ss");
        final String formattedTime = df.format(c.getTime());
        return  formattedTime;
    }


}
