package com.example.ingri.exercise1;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import static com.example.ingri.exercise1.LocalService.*;

public class MainActivity extends AppCompatActivity {

    LocalService binder;
    TextView txtView;
    Button btnDate, btnTime, btnConnect;
    public boolean Connected = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txtView = findViewById(R.id.txtView);
        btnDate = findViewById(R.id.btnDate);
        btnTime = findViewById(R.id.btnTime);
        btnConnect = findViewById(R.id.btnConnect);
    }

    public void onDate(){
        String formattedDate = formattedDate();
        txtView.setText(formattedDate);
    }

    public void onTime(){
        String formattedTime = formattedTime();
        txtView.setText(formattedTime);
    }

    public void onConnect (View view){
        if (Connected){
            Connected = false;
            btnDate.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    onDate();
                }
            });
            btnTime.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    onTime();
                }
            });

            txtView.setText("Connected");
            btnConnect.setText("Disconnect");
            btnDate.setEnabled(true);
            btnTime.setEnabled(true);
        }
        else {
            Connected= true;
            btnDate.setOnClickListener(null);
            btnTime.setOnClickListener(null);
            btnConnect.setText("Connect");
            txtView.setText("Disconnected");
            btnDate.setEnabled(false);
            btnTime.setEnabled(false);
        }
        ServiceConnection serviceConnection = new ServiceConnection() {
            @Override
            public void onServiceConnected(ComponentName name, IBinder service) {


            }

            @Override
            public void onServiceDisconnected(ComponentName name) {

            }
        };


    }
}
