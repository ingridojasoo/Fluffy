package com.example.ingri.targe17ojasoo;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    private static final double factor  = 0.2;
    private EditText unit_price, number_of_units, Amount_excl_of_VAT, VAT, Amount_incl_of_VAT;
    private RadioButton ex, in;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        unit_price = findViewById(R.id.unit_price);
        number_of_units = findViewById(R.id.number_of_units);
        Amount_excl_of_VAT = findViewById(R.id.Amount_excl_of_VAT);
        VAT = findViewById(R.id.VAT);
        Amount_incl_of_VAT = findViewById(R.id.Amount_incl_of_VAT);
        ex = findViewById(R.id.ex);
        in = findViewById(R.id.in);
    }

    public static double price_excl_vat (double unit_price, double number_of_units){
        return unit_price * number_of_units;
    }

    public static double vat_price (double unit_price, double number_of_units){
        double price_of_units = unit_price * number_of_units;
        double price_of_vat = price_of_units * factor;
        return price_of_vat;
    }

    public static double price_incl_vat(double unit_price, double number_of_units){
        double price_of_units = unit_price * number_of_units;
        double price_of_vat = price_of_units * factor;
        double price_incl_vat = price_of_vat + price_of_units;
        return price_incl_vat;
    }

    public void onClick(View view){
        if (view.getId()== R.id.clear){
            unit_price.setText("");
            number_of_units.setText("");
            Amount_excl_of_VAT.setText("");
            VAT.setText("");
            Amount_incl_of_VAT.setText("");
        }
        else if (view.getId()== R.id.ok){
            if (unit_price.getText().length()==0){
                Toast.makeText(this, "Please enter a unit price", Toast.LENGTH_SHORT).show();
                return;
            }

            else if (view.getId()== R.id.ok){
                Toast.makeText(this, "", Toast.LENGTH_SHORT).show();
                return;
            }

            double value = Double.parseDouble(unit_price.getText().toString());
            double value2 = Double.parseDouble(number_of_units.getText().toString());

            if (ex.isChecked()){
                Amount_excl_of_VAT.setText(String.valueOf(price_excl_vat(value, value2)));
                VAT.setText(String.valueOf(vat_price(value,value2)));
            }
            else {
                VAT.setText(String.valueOf(vat_price(value,value2)));
                Amount_incl_of_VAT.setText(String.valueOf(price_incl_vat(value,value2)));
            }
        }
    }
}















