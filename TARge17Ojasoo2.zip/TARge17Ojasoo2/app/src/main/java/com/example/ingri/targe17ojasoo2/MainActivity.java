package com.example.ingri.targe17ojasoo2;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.AndroidException;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    EditText First_name, Last_name;
    ListView listView;
    Button add_name;
    ArrayList<String> addArray = new ArrayList<>();
    ListView show;
    ListView listView1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        First_name = (EditText) findViewById(R.id.First_name);
        Last_name = (EditText) findViewById(R.id.Last_name);
        listView = findViewById(R.id.listView1);
        show = (ListView)findViewById(R.id.listView1);
        listView = findViewById(R.id. listView1);
        add_name = (Button)findViewById(R.id.add_name);
        add_name.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String getInput = First_name.getText().toString();
                String getInput2 = Last_name.getText().toString();

                if (addArray.contains(getInput)){
                    Toast.makeText(getBaseContext(), "Added to arrey", Toast.LENGTH_SHORT).show();
                }
                else if (getInput == null || getInput.trim().equals("")){
                    Toast.makeText(getBaseContext(), "Please add first name ", Toast.LENGTH_SHORT).show();
                }
                else  if (getInput2 == null || getInput2.trim().equals("")){
                    Toast.makeText(getBaseContext(), "Please add last name", Toast.LENGTH_SHORT).show();
                }

                else {
                    addArray.add(getInput + " " + getInput2);
                    ArrayAdapter<String>adapter = new ArrayAdapter<String>(MainActivity.this, android.R.layout.simple_list_item_1, addArray);
                    show.setAdapter(adapter);
                    ((EditText)findViewById(R.id.First_name)).setText(" ");
                    ((EditText)findViewById(R.id.Last_name)).setText(" ");

                }
            }
        });
    }

    public void clear(View view) {
        if (view.getId()== R.id.clr){
            First_name.setText(" ");
            Last_name.setText(" ");
        }
    }

    public void add(View view) {
    }
}
